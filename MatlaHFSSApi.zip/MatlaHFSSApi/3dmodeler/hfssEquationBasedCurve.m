% ----------------------------------------------------------------------------
% function hfssEquationBasedCurve(fid,name,XtFunction, YtFunction, ZtFunction,tStart,tEnd,NumOfPointsOnCurve,Units)

% 
% Description :
% -------------
% Create the VB Script necessary to construct a  EquationBasedCurve using the HFSS
% line.
%
% Parameters :
% ------------
% fid     - file identifier of the HFSS script file.
% Name    - name of the rectangle object (appears in the HFSS objects tree).
% XtFunction, -�ַ���X��������
% YtFunction, -�ַ���X��������
% ZtFunction,-�ַ���X��������
% tStart, -�ַ���_tstart
% tEnd,   -�ַ���_tend
% NumOfPointsOnCurve,-�ַ��͵���
% Units)
%
% Note :

% ----------------------------------------------------------------------------
% This file is part of HFSS-MATLAB-API.
%
%
% Copyright 2020, LING-JUN YANG
% ----------------------------------------------------------------------------
% Width and Height follow the right-hand rule. If the Axis is Z, then Width
% represents X-direction size and Height represents the Y-direction size 
% and so on ...
function hfssEquationBasedCurve(fid,name,XtFunction, YtFunction, ZtFunction,tStart,tEnd,NumOfPointsOnCurve)

%Transparency = 0.5;

% Preamble.
fprintf(fid, '\n');
fprintf(fid, 'oEditor.CreateEquationCurve _\n');

% Rectangle Parameters.
fprintf(fid, 'Array("NAME:EquationBasedCurveParameters", _\n');
fprintf(fid, '"XtFunction:=","%s", _\n', XtFunction);
fprintf(fid, '"YtFunction:=","%s", _\n', YtFunction);
fprintf(fid, '"ZtFunction:=","%s", _\n', ZtFunction);
fprintf(fid, '"tStart:=","%s", _\n', tStart);
fprintf(fid, '"tEnd:=","%s", _\n', tEnd);
fprintf(fid, '"NumOfPointsOnCurve:=","%s", _\n', NumOfPointsOnCurve);
fprintf(fid, '"Version:=",1, _\n');
fprintf(fid, 'Array("NAME:PolylineXSection", _\n');
fprintf(fid, '"XSectionType:=","None", _\n');
fprintf(fid, '"XSectionOrient:=","Auto", _\n');
fprintf(fid, '"XSectionWidth:=","0", _\n');
fprintf(fid, '"XSectionTopWidth:=","0", _\n');
fprintf(fid, '"XSectionHeight:=","0", _\n');
fprintf(fid, '"XSectionNumSegments:=","0", _\n');
fprintf(fid, '"XSectionBendType:=","Corner")), _\n');
fprintf(fid, 'Array("NAME:Attributes", _\n');
fprintf(fid, '"Name:=","%s", _\n',name);
fprintf(fid, '"Flags:=", "", _\n');
fprintf(fid, '"Color:=", "(132 132 193)", _\n');
fprintf(fid, '"Transparency:=", 0, _\n');
fprintf(fid, '"PartCoordinateSystem:=","Global", _\n');
fprintf(fid, '"UDMId:=", "", _\n');
fprintf(fid, '"MaterialValue:=", "" & Chr(34) & "vacuum" & Chr(34) & "", _\n');
fprintf(fid, '"SurfaceMaterialValue:=", "" & Chr(34) & "vacuum" & Chr(34) & "", _\n');
fprintf(fid, '"SolveInside:=", true,_\n');
fprintf(fid, '"IsMaterialEditable:=",true, "UseMaterialAppearance:=", false, "IsLightweight:=", false)')
